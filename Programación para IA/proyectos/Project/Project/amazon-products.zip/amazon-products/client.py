"""Cliente de demostración: descubre e invoca las tres herramientas por HTTP.

Snippet provisto en MCP_HTTP.md. Se ejecuta con main.py mientras server.py corre
en otra terminal. Los casos incluyen entradas válidas e inválidas; la llamada con
top_k=0 debe producir un error y la siguiente debe funcionar en la misma conexión.
"""

from typing import Any

from mcp import Client


async def demonstrate() -> None:
    calls: list[tuple[str, dict[str, Any]]] = [
        ("search_products", {"query": "A portable waterproof Bluetooth speaker", "top_k": 3}),
        ("analyze_product", {"product_id": "B0BCTJMN63"}),
        ("compare_products", {"product_ids": ["B0BCTJMN63", "B09MMWM2Y8"]}),
        ("analyze_product", {"product_id": "UNKNOWN_PRODUCT"}),
        ("search_products", {"query": "delivery", "top_k": 0}),
        ("search_products", {"query": "Comfortable headphones with good sound", "top_k": 2}),
    ]
    async with Client("http://127.0.0.1:8000/mcp") as client:
        tools = await client.list_tools()
        print("Tools:", [tool.name for tool in tools.tools])
        for name, arguments in calls:
            print(f"\n{name}: {arguments}")
            result = await client.call_tool(name, arguments)
            print("Tool error:", result.is_error)
            print(result.model_dump_json(indent=2))
